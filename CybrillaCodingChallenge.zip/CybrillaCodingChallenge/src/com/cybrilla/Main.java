/**
 * 
 */
package com.cybrilla;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

/**
 * @author Caaiuu
 *
 */
public class Main {
	
	String bank_ifsc_code, merchant_transaction_ref, transaction_date, payment_gateway_merchant_referance, bank_account_number, amount, msg;

	public static String byteArrayToHexString(byte[] b) {
		  String result = "";
		  for (int i=0; i < b.length; i++) {
		    result +=
		          Integer.toString( ( b[i] & 0xff ) + 0x100, 16).substring( 1 );
		  }
		  return result;
		}
	
	public String toSHA1() {
		msg = bank_ifsc_code+"|"+bank_account_number+"|"+amount+"|"+merchant_transaction_ref+"|"+transaction_date+"|"+payment_gateway_merchant_referance;
		String temp = msg;
		byte[] msgArray = temp.getBytes();
	    MessageDigest md = null;
	    try {
	        md = MessageDigest.getInstance("SHA-1");
	    }
	    catch(NoSuchAlgorithmException e) {
	        e.printStackTrace();
	    } 
	    byte[] sol = md.digest(msgArray);
	    String advncMsg = byteArrayToHexString(sol);
	    return msg+"|hash="+advncMsg;
	}
	
	public static void main(String[] args) {
		String bank_ifsc_code, merchant_transaction_ref, transaction_date, payment_gateway_merchant_referance, bank_account_number, amount, msg, payload_with_sha;
		Scanner sc = new Scanner(System.in);
		Main m = new Main();
		bank_ifsc_code = sc.nextLine();
		bank_account_number = sc.nextLine();
		amount = sc.nextLine();
		merchant_transaction_ref = sc.nextLine();
		transaction_date = sc.nextLine();
		payment_gateway_merchant_referance = sc.nextLine();
		String encryption_key = "Q9fbkBF8au24C9wshGRW9ut8ecYpyXye5vhFLtHFdGjRg3a4HxPYRfQaKutZx5N4";
		
		m.bank_ifsc_code = bank_ifsc_code;
		m.merchant_transaction_ref = merchant_transaction_ref;
		m.transaction_date = transaction_date;
		m.bank_account_number = bank_account_number;
		m.amount = amount;
		m.payment_gateway_merchant_referance = payment_gateway_merchant_referance;
		payload_with_sha = m.toSHA1();
		try {
			EncryptionManager.encrypt(encryption_key.getBytes(), payload_with_sha.getBytes());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
