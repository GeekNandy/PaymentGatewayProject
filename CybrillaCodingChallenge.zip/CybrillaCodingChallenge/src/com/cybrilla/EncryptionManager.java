/**
 * 
 */
package com.cybrilla;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class EncryptionManager {

	public static String ALGORITHM = "AES";
	private static String AES_CBS_PADDING = "AES/CBC/PKCS5Padding";
	

	public static byte[] encrypt(final byte[] key, final byte[] message) throws Exception {
		return EncryptionManager.encryptDecrypt(Cipher.ENCRYPT_MODE, key, message);
	}

	public static byte[] decrypt(final byte[] key, final byte[] message) throws Exception {
		return EncryptionManager.encryptDecrypt(Cipher.DECRYPT_MODE, key, message);
	}

	private static byte[] encryptDecrypt(final int mode, final byte[] key, final byte[] message)
			throws Exception {
		final Cipher cipher = Cipher.getInstance(AES_CBS_PADDING);
		final SecretKeySpec keySpec = new SecretKeySpec(key, ALGORITHM);
		cipher.init(mode, keySpec);
		return cipher.doFinal(message);
	}
}
